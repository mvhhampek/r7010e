close all
clear all
clc
%%
ptCloud = pcread('fountain.ply');
pcshow(ptCloud);